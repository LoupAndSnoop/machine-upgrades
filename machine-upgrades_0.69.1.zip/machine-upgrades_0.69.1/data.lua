require("__machine-upgrades__/lib/lib")
require("__machine-upgrades__/lib/technology-maker")


require("__machine-upgrades__/prototypes/beacon")
require("__machine-upgrades__/prototypes/module")


require("__machine-upgrades__.script.test-suite")