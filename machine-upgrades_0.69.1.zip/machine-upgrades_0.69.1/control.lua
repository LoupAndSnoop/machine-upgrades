require("__machine-upgrades__/lib/lib")

require("__machine-upgrades__.script.event-lib")
require("__machine-upgrades__.script.technology-linker")
require("__machine-upgrades__.script.automatic-tech-linker")



require("__machine-upgrades__.script.test-suite")